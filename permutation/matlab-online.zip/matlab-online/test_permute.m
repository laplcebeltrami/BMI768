function [stat_s, time_s] = test_permute(x,y,per_s)
%function [stat_s, time_s] = test_permute(x,y,per_s)
% The function computes the two-sample t-statitic of vector data using the standard permutation
% test. If follows the method explained in 
%
% Chung, M.K., Xie, L, Huang, S.-G., Wang, Y., Yan, J., Shen, L. 2019 Rapid 
% acceleration of the permutation test via transpositions, International 
% Workshop on Connectomics in NeuroImaging, Lecture Notes in Computer Science
% 11848:42-53 
% http://www.stat.wisc.edu/~mchung/papers/chung.2019.CNI.pdf
%
% INPUT
% x    : input vector data of size m x l (m= number of subjects, l=number of data per subject) 
% y    : input vector data of size n x l (n= number of subjects, l=number of data per subject)
% per_s: number of permutations
%
% OUTPUT
% stat_s:  two-sample t-statistic of all permutations
% time_s:  run time it took to compute the statistics


%
% This code is downloaded from
% http://www.stat.wisc.edu/~mchung/transpositions
%
% (C) 2019 Moo K. Chung  mkchung@wisc.edu
% University of Wisconsin-Madison
% 
%
%

tic

m=size(x,1);
n=size(y,1);
l=size(x,2); %dimension of vector
z=[x; y];  %Combine the data
stat_s=zeros(per_s,l);

for i=1:per_s %each iteration gives a permutation
    z=z(randperm(m+n)); %random permutation of data z.
    %Unlike the transposition method, you cannot
    %save the whole permutations in prior since it takes so much memory
    %for large m,n.
    x=z(1:m);y=z(m+1:m+n); %permuted data is split into group 1 and 2
    stat_s(i,:)=(mean(x)-mean(y)).*sqrt(m*n*(m+n-2)./((m+n)*((m-1)*var(x)+(n-1)*var(y)))); %t-stat
end

toc
time_s=toc;