function [stat_t, time_t] = transpose_corr(x,y,per_t)

%function [stat_t, time_t] = test_transpose(x1,x2,per_t)
% The function computes the sequence of correlation of vector data x and y
% via transpositions. It follows the method explained in 
%
% Chung, M.K., Xie, L, Huang, S.-G., Wang, Y., Yan, J., Shen, L. 2019 Rapid 
% acceleration of the permutation test via transpositions, International 
% Workshop on Connectomics in NeuroImaging, Lecture Notes in Computer Science
% 11848:42-53 
% http://www.stat.wisc.edu/~mchung/papers/chung.2019.CNI.pdf
%
% INPUT
% x    : input data of size m x p (m= number of subjects, p=number 
%         of data/voxels/edges per subject) 
% y    : input data of size m x p (n= number of subjects, =number 
%         of data/voxels/edges per subject). Since we are computing correlation of x and 
%         y, they have to be the same size
% per_t: number of transpositions
%
% OUTPUT
% stat_t   :  the average of correlations over transpositions. It is sequentially 
%             computed in the online fashion to save computer memory. Note stat_t 
%             is of length per_t. stat(50) is the average correlation over 50 transpositions.  
% time_t   :  run time it took to compute the statistics
%
%
% This code is downloaded from
% http://www.stat.wisc.edu/~mchung/transpositions
%
% (C) 2019 Moo K. Chung
%  mkchung@wisc.edu
% University of Wisconsin-Madison


%The following 20 simulated data was used for testing
% 
% a=[0.1518   -0.5024
%   -2.2439   -0.0720
%    1.3997   -0.2961
%   -0.0870    2.6186
%    1.3410   -1.0642]
%
%x=a(:,1)
%y=a(:,2)

%corr(x,y) =  -0.2425



tic

m=size(x,1);
p=size(x,2);


mx1=sum(x);my1=sum(y);%old mean (without division)
mean_x=kron(mean(x),ones(m,1)); %duplicate means
mean_y=kron(mean(y),ones(m,1)); %duplicate means

vx1=sum((x-mean_x).*(x-mean_x));    %variance of x (without division)
vy1=sum((y-mean_y).*(y-mean_y));    %variance of y (without division)
cov1=m*sum((x-mean_x).*(y-mean_y)); %old covariance (without devision)
CM=cov1./(m*(sqrt(vx1.*vy1)));     %new pearson correlation

%The above line equivalent to the following lines
%CM=corr(MZ1vec,MZ2vec);
%CM=diag(CM);


stat_t=CM;
pi=randi(m,per_t,1); % random transpostion index


for k=2:per_t
    
    
    a=x(pi(k),:);    % a is now x
    x(pi(k),:)=y(pi(k),:);  %x transposed
    b=y(pi(k),:); %b is now y
    y(pi(k),:)=a; %y transposed
    
    %Validation: for pi=4 that swaps 4th position, corr(x,y)=-0.2205. This should match
    %with c1 value.
    
    mx2=mx1+b-a;  %new mean
    my2=my1+a-b;
    
    vx2=vx1+(mx1.^2-mx2.^2)/m + b.^2-a.^2; %new variance of x
    vy2=vy1+(my1.^2-my2.^2)/m + a.^2-b.^2; %new variance of y
    cov2=cov1+(a-b).^2+(a-b).*(my1-mx1);%new covariance of x and y
    c1=real(cov2./(m*(sqrt(vx2.*vy2)))); %new pearson correlation. This should match with corr(x,y)
    
    %start with random permutation
    % correlation is iterately computed
    % (corr1 + corr2 +... + corrk)/k = newcorr
    % (corr1 + corr2 + .. + corr(k-1))/(k-1) = (k*newcorr - corrk)/(k-1) = oldcorr
    % (oldcorr*(k-1) + corrk)/k = newcorr

    CM=(CM*(k-1)+c1)/k;  %the average correlation of k sequencial correlations
    CM=real(CM); %in case sqrt gives tiny imaginary numbers.
    CM(find(isinf(CM)))=0;
    CM(find(isnan(CM)))=0;
    stat_t=[stat_t; CM];
    
    mx1=mx2;my1=my2;vx1=vx2;vy1=vy2;cov1=cov2;%prepare for the next iteration
    
     
end


time_t = toc;


